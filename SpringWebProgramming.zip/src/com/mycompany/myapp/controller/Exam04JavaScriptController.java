package com.mycompany.myapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Exam04JavaScriptController {

	@RequestMapping("/javascript/exam01")
	public String javascriptExam01() {
		return "javascript/exam01";
	}

	@RequestMapping("/javascript/exam02")
	public String javascriptExam02() {
		return "javascript/exam02";
	}

	@RequestMapping("/javascript/exam03")
	public String javascriptExam03() {
		return "javascript/exam03";
	}

	@RequestMapping("/javascript/exam04")
	public String javascriptExam04() {
		return "javascript/exam04";
	}

	@RequestMapping("/javascript/exam05")
	public String javascriptExam05() {
		return "javascript/exam05";
	}

	@RequestMapping("/javascript/exam06")
	public String javascriptExam06() {
		return "javascript/exam06";
	}

	@RequestMapping("/javascript/exam07")
	public String javascriptExam07() {
		return "javascript/exam07";
	}

	@RequestMapping("/javascript/exam08")
	public String javascriptExam08() {
		return "javascript/exam08";
	}

	@RequestMapping("/javascript/exam09")
	public String javascriptExam09() {
		return "javascript/exam09";
	}

	@RequestMapping("/javascript/exam10")
	public String javascriptExam10() {
		return "javascript/exam10";
	}

	@RequestMapping("/javascript/exam11")
	public String javascriptExam11() {
		return "javascript/exam11";
	}
}
