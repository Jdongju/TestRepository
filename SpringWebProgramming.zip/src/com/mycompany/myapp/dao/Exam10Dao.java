package com.mycompany.myapp.dao;

public interface Exam10Dao {

	public void insert();

	public void select();
}
