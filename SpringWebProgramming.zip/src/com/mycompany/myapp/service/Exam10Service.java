package com.mycompany.myapp.service;

public interface Exam10Service {
	public void join();

	public void login();

}
